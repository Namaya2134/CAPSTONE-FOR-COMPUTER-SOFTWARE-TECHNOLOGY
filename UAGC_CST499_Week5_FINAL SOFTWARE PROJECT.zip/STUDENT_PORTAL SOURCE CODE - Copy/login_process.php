<?php
// login_process.php
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

require 'db.php';

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    echo '<p>Username and password are required. <a href="login.php">Go back</a></p>';
    exit;
}

// Look up the user
$stmt = $conn->prepare("SELECT student_id, username, password FROM students WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    // Verify hashed password
    if (password_verify($password, $row['password'])) {
        $_SESSION['user_id']  = $row['student_id'];
        $_SESSION['username'] = $row['username'];

        // Success → go to dashboard
        header('Location: dashboard.php');
        exit;
    }
}

// If we got here, login failed
echo '<p>Invalid username or password. <a href="login.php">Try again</a></p>';
