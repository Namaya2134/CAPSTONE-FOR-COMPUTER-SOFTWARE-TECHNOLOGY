<?php
// my_enrollments.php — shows the logged-in student's enrollments with Cancel action
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require 'db.php';

$student_id = (int)$_SESSION['user_id'];
$username   = htmlspecialchars($_SESSION['username'] ?? 'Student');

// Include enrollment_id so we can cancel specific rows
$sql = "
    SELECT e.enrollment_id, c.course_name, e.status
    FROM enrollment e
    JOIN courses c ON c.course_id = e.course_id
    WHERE e.student_id = ?
    ORDER BY e.status ASC, c.course_name ASC
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <title>My Enrollments</title>
</head>
<body>
  <h2>My Enrollments</h2>
  <p>Welcome, <?php echo $username; ?> |
     <a href="dashboard.php">Dashboard</a> |
     <a href="courses.php">Courses</a> |
     <a href="logout.php">Logout</a></p>

  <?php if ($result && $result->num_rows > 0): ?>
    <table border="1" cellpadding="8" cellspacing="0">
      <tr>
        <th>Course</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['course_name']); ?></td>
          <td><?php echo htmlspecialchars($row['status']); ?></td>
          <td>
            <form method="post" action="cancel_enrollment.php" style="margin:0"
                  onsubmit="return confirm('Cancel this enrollment?');">
              <input type="hidden" name="enrollment_id" value="<?php echo (int)$row['enrollment_id']; ?>">
              <button type="submit">Cancel</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p>You have no enrollments yet.</p>
  <?php endif; ?>

</body>
</html>
