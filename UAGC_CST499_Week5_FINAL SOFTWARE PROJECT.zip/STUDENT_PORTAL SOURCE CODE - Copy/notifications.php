<?php
// notifications.php — view and mark notifications as read (course-aware)
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

require 'db.php';

$student_id = (int)$_SESSION['user_id'];
$username   = htmlspecialchars($_SESSION['username'] ?? 'Student');

// Handle actions (mark one or all as read)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['notif_id'])) {
        $nid = (int)$_POST['notif_id'];
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND student_id = ?");
        $stmt->bind_param("ii", $nid, $student_id);
        $stmt->execute();
        $stmt->close();
    }

    if (isset($_POST['mark_all'])) {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE student_id = ?");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $stmt->close();
    }

    header('Location: notifications.php');
    exit;
}

// Fetch notifications with joined course name
$sql = "
  SELECT n.id, n.message, n.is_read, n.created_at, n.course_id, c.course_name
  FROM notifications n
  LEFT JOIN courses c ON n.course_id = c.course_id
  WHERE n.student_id = ?
  ORDER BY n.is_read ASC, n.created_at DESC
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Notifications</title>
</head>
<body>
  <h2>Notifications</h2>
  <p>Welcome, <?php echo $username; ?> |
     <a href="dashboard.php">Dashboard</a> |
     <a href="courses.php">Courses</a> |
     <a href="my_enrollments.php">My Enrollments</a> |
     <a href="logout.php">Logout</a></p>

  <form method="post" style="margin: 10px 0;">
    <button type="submit" name="mark_all" value="1">Mark all as read</button>
  </form>

  <?php if ($result && $result->num_rows > 0): ?>
    <table border="1" cellpadding="8" cellspacing="0">
      <tr>
        <th>Status</th>
        <th>Message</th>
        <th>Time</th>
        <th>Action</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo $row['is_read'] ? 'read' : 'unread'; ?></td>
          <td>
            <?php echo htmlspecialchars($row['message']); ?>
            <?php if (!empty($row['course_id'])): ?>
              ( <a href="courses.php">View <?php echo htmlspecialchars($row['course_name'] ?? 'course'); ?></a> )
            <?php endif; ?>
          </td>
          <td><?php echo htmlspecialchars($row['created_at']); ?></td>
          <td>
            <?php if (!$row['is_read']): ?>
              <form method="post" style="margin:0">
                <input type="hidden" name="notif_id" value="<?php echo (int)$row['id']; ?>">
                <button type="submit">Mark read</button>
              </form>
            <?php else: ?>
              —
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p>No notifications yet.</p>
  <?php endif; ?>

</body>
</html>
