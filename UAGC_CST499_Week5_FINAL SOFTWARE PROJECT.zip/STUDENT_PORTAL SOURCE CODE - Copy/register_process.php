<?php
// register_process.php — create account, then auto-login
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.php');
    exit;
}

require 'db.php';

// 1) Collect + basic validation
$full_name = trim($_POST['full_name'] ?? '');
$phone     = trim($_POST['phone'] ?? '');
$email     = trim($_POST['email'] ?? '');
$username  = trim($_POST['username'] ?? '');
$password  = $_POST['password'] ?? '';

$errors = [];
if ($full_name === '')                         $errors[] = 'Full name is required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
if ($username === '')                          $errors[] = 'Username is required.';
if (strlen($password) < 6)                     $errors[] = 'Password must be at least 6 characters.';

if ($errors) {
    echo '<h3>Fix these issues:</h3><ul>';
    foreach ($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>';
    echo '</ul><p><a href="register.php">Go back</a></p>';
    exit;
}

// 2) Check for duplicates (email or username already taken)
$check = $conn->prepare("SELECT COUNT(*) FROM students WHERE email = ? OR username = ?");
$check->bind_param("ss", $email, $username);
$check->execute();
$check->bind_result($count);
$check->fetch();
$check->close();

if ($count > 0) {
    echo '<p>Email or username already exists. <a href="register.php">Go back</a></p>';
    exit;
}

// 3) Insert the new student (hash the password)
$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare(
    "INSERT INTO students (full_name, phone, email, username, password)
     VALUES (?, ?, ?, ?, ?)"
);
$stmt->bind_param("sssss", $full_name, $phone, $email, $username, $hash);

if ($stmt->execute()) {
    // 4) Auto-login and redirect to dashboard
    $_SESSION['user_id']  = $conn->insert_id;  // new student's ID
    $_SESSION['username'] = $username;
    header('Location: dashboard.php');
    exit;
} else {
    echo '<p>Something went wrong: '.htmlspecialchars($stmt->error).'</p>';
}

$stmt->close();
$conn->close();
