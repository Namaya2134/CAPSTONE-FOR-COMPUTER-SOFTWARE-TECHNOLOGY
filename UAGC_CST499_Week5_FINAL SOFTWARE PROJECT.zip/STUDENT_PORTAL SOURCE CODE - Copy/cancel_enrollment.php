<?php
// cancel_enrollment.php — drop a course; triggers handle counts; still notify promotions
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
require 'db.php';

$student_id    = (int)$_SESSION['user_id'];
$enrollment_id = (int)($_POST['enrollment_id'] ?? 0);
if ($enrollment_id <= 0) die('Invalid request. <a href="my_enrollments.php">Back</a>');

// Find the enrollment and verify ownership
$sql = "SELECT course_id, status FROM enrollment WHERE enrollment_id = ? AND student_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $enrollment_id, $student_id);
$stmt->execute();
$enr = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$enr) die('Enrollment not found. <a href="my_enrollments.php">Back</a>');

$course_id = (int)$enr['course_id'];
$status    = $enr['status'];

try {
  $conn->begin_transaction();

  // Delete the enrollment (trigger will decrement if it was enrolled)
  $stmt = $conn->prepare("DELETE FROM enrollment WHERE enrollment_id = ? AND student_id = ?");
  $stmt->bind_param("ii", $enrollment_id, $student_id);
  if (!$stmt->execute()) throw new Exception($stmt->error);
  $stmt->close();

  // If they freed an enrolled seat, promote first waitlisted (if any)
  if ($status === 'enrolled') {
    $promote = $conn->query("
      SELECT enrollment_id FROM enrollment
      WHERE course_id = $course_id AND status = 'waitlisted'
      ORDER BY enrollment_id ASC
      LIMIT 1
    ");
    if ($promote && $promote->num_rows === 1) {
      $wait_enrollment_id = (int)$promote->fetch_assoc()['enrollment_id'];

      // Update status to enrolled (trigger will increment)
      $conn->query("UPDATE enrollment SET status = 'enrolled' WHERE enrollment_id = $wait_enrollment_id");

      // Notify promoted student (course-specific)
      $sRes = $conn->query("SELECT student_id FROM enrollment WHERE enrollment_id = $wait_enrollment_id");
      if ($sRes && $srow = $sRes->fetch_assoc()) {
        $promoted_student_id = (int)$srow['student_id'];
        $courseName = "this course";
        $cRes = $conn->query("SELECT course_name FROM courses WHERE course_id = $course_id");
        if ($cRes && $crow = $cRes->fetch_assoc()) $courseName = $crow['course_name'];

        $msg = "You have been moved from waitlist to ENROLLED in {$courseName}.";
        $n = $conn->prepare("INSERT INTO notifications (student_id, course_id, message) VALUES (?, ?, ?)");
        $n->bind_param("iis", $promoted_student_id, $course_id, $msg);
        if (!$n->execute()) throw new Exception($n->error);
        $n->close();
      }
    }
  }

  $conn->commit();
  echo "<p>Enrollment cancelled. <a href='my_enrollments.php'>Back to My Enrollments</a></p>";

} catch (Exception $e) {
  $conn->rollback();
  echo "<p>Could not cancel: ".htmlspecialchars($e->getMessage())." <a href='my_enrollments.php'>Back</a></p>";
}
$conn->close();
