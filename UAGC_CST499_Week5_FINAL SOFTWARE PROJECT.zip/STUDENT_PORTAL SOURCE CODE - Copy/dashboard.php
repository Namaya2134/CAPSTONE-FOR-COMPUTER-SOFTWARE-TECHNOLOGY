<?php
// dashboard.php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$username   = htmlspecialchars($_SESSION['username'] ?? 'Student');
$user_id    = (int)($_SESSION['user_id'] ?? 0);

// get unread notifications count
require 'db.php';
$unread = 0;
$stmt = $conn->prepare("SELECT COUNT(*) FROM notifications WHERE student_id = ? AND is_read = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($unread);
$stmt->fetch();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
</head>
<body>
  <h2>Welcome, <?php echo $username; ?>!</h2>
  <p>This is your dashboard.</p>

  <p>
    <a href="courses.php">View Courses</a> |
    <a href="my_enrollments.php">My Enrollments</a> |
    <a href="notifications.php">Notifications<?php echo $unread ? " ($unread)" : ""; ?></a> |
    <a href="logout.php">Logout</a>
  </p>
</body>
</html>
