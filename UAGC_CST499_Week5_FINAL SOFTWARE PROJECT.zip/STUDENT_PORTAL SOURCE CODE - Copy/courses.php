<?php
// courses.php — list available courses
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require 'db.php';
$username = htmlspecialchars($_SESSION['username'] ?? 'Student');

// fetch all courses
$result = $conn->query("SELECT course_id, course_name, capacity, current_enrollment FROM courses ORDER BY course_id ASC");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Courses</title>
</head>
<body>
  <h2>Available Courses</h2>
  <p>Welcome, <?php echo $username; ?> |
     <a href="dashboard.php">Dashboard</a> |
     <a href="my_enrollments.php">My Enrollments</a> |
     <a href="logout.php">Logout</a></p>

  <?php if ($result && $result->num_rows > 0): ?>
    <table border="1" cellpadding="8" cellspacing="0">
      <tr>
        <th>Course</th>
        <th>Capacity</th>
        <th>Enrolled</th>
        <th>Action</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()):
        $full = ($row['current_enrollment'] >= $row['capacity']);
      ?>
        <tr>
          <td><?php echo htmlspecialchars($row['course_name']); ?></td>
          <td><?php echo (int)$row['capacity']; ?></td>
          <td><?php echo (int)$row['current_enrollment']; ?></td>
          <td>
            <form method="post" action="enroll.php" style="margin:0">
              <input type="hidden" name="course_id" value="<?php echo (int)$row['course_id']; ?>">
              <button type="submit"><?php echo $full ? 'Join Waitlist' : 'Enroll'; ?></button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p>No courses found.</p>
  <?php endif; ?>

</body>
</html>
