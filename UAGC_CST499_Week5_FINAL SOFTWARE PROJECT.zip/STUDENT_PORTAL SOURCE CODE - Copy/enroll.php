<?php
// enroll.php — duplicate check + transaction; counts handled by DB triggers
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
require 'db.php';

$student_id = (int)($_SESSION['user_id'] ?? 0);
$course_id  = (int)($_POST['course_id'] ?? 0);
if ($course_id <= 0) die('Invalid course. <a href="courses.php">Back to Courses</a>');

// Prevent duplicates
$chk = $conn->prepare("SELECT status FROM enrollment WHERE student_id = ? AND course_id = ?");
$chk->bind_param("ii", $student_id, $course_id);
$chk->execute();
if ($row = $chk->get_result()->fetch_assoc()) {
  echo "<p>You are already ".htmlspecialchars($row['status'])." for this course. <a href='courses.php'>Back to Courses</a></p>";
  $chk->close(); $conn->close(); exit;
}
$chk->close();

try {
  $conn->begin_transaction();

  // Lock course row to decide status safely
  $courseStmt = $conn->prepare("SELECT capacity, current_enrollment FROM courses WHERE course_id = ? FOR UPDATE");
  $courseStmt->bind_param("i", $course_id);
  $courseStmt->execute();
  $course = $courseStmt->get_result()->fetch_assoc();
  $courseStmt->close();
  if (!$course) throw new Exception('Course not found.');

  $capacity = (int)$course['capacity'];
  $current  = (int)$course['current_enrollment'];
  $status   = ($current >= $capacity) ? 'waitlisted' : 'enrolled';

  // Insert enrollment (triggers will adjust counts)
  $ins = $conn->prepare("INSERT INTO enrollment (student_id, course_id, status) VALUES (?, ?, ?)");
  $ins->bind_param("iis", $student_id, $course_id, $status);
  $ins->execute();
  $ins->close();

  $conn->commit();
  echo "<p>You have been {$status} for this course. <a href='courses.php'>Back to Courses</a></p>";

} catch (mysqli_sql_exception $e) {
  $conn->rollback();
  if ($e->getCode() == 1062) {
    echo "<p>You are already enrolled (or waitlisted) in this course. <a href='courses.php'>Back to Courses</a></p>";
  } else {
    echo "<p>Error: ".htmlspecialchars($e->getMessage())."</p>";
  }
} catch (Exception $e) {
  $conn->rollback();
  echo "<p>Error: ".htmlspecialchars($e->getMessage())."</p>";
}
$conn->close();
