<?php
require 'db.php';
echo "✅ Database connection successful!";
?>
