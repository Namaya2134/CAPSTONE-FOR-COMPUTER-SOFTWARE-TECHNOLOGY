<?php
// db.php — database connection
$host = 'localhost';
$user = 'root';
$pass = '';        // if you set a MySQL root password, put it here
$db   = 'student_portal';
$port = 3306;      // change if you used a different MySQL port

$conn = new mysqli($host, $user, $pass, $db, $port);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
?>
